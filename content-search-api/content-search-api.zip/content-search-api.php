<?php
/**
 * Plugin Name: Content Search API
 * Plugin URI: https://github.com/tu-usuario/content-search-api
 * Description: API REST completa con análisis de contenido, SEO, analytics y recomendaciones. Sistema de vistas integrado. Incluye soporte completo para Yoast SEO (lectura/escritura). Compatible con AdminResh. NUEVO: Soporte completo para Polylang FREE.
 * Version: 2.1.0
 * Author: AdminResh Team
 * License: GPL v2 or later
 * Text Domain: content-search-api
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CSA_PLUGIN_FILE', __FILE__);
define('CSA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CSA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CSA_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load the core class
require_once CSA_PLUGIN_DIR . 'includes/class-csa-core.php';

/**
 * Initialize the plugin
 */
function csa_init() {
    CSA_Core::get_instance();
}
add_action('plugins_loaded', 'csa_init');

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, array('CSA_Core', 'activate'));

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, array('CSA_Core', 'deactivate'));

/**
 * Add admin menu for testing
 */
add_action('admin_menu', function() {
    add_options_page(
        'Content Search API',
        'Content Search API',
        'manage_options',
        'content-search-api',
        'csa_admin_page'
    );
});

/**
 * Admin page callback
 */
function csa_admin_page() {
    ?>
    <div class="wrap">
        <h1>Content Search API</h1>
        <div class="notice notice-success">
            <p><strong>✅ Plugin activado correctamente!</strong></p>
        </div>
        
        <h2>Estado del Plugin</h2>
        <table class="form-table">
            <tr>
                <th>Versión</th>
                <td><?php echo CSA_Core::VERSION; ?></td>
            </tr>
            <tr>
                <th>API Namespace</th>
                <td><?php echo CSA_Core::get_api_namespace(); ?></td>
            </tr>
            <tr>
                <th>Polylang</th>
                <td><?php echo function_exists('pll_languages_list') ? '✅ Activo' : '❌ No detectado'; ?></td>
            </tr>
            <tr>
                <th>Yoast SEO</th>
                <td><?php echo class_exists('WPSEO_Meta') ? '✅ Activo' : '❌ No detectado'; ?></td>
            </tr>
        </table>
        
        <h2>Endpoints Disponibles</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
                <h3>📝 Contenido y Posts</h3>
                <ul>
                    <li><strong>1. Búsqueda:</strong> <code>/search</code></li>
                    <li><strong>2. Posts/Páginas:</strong> <code>/posts</code></li>
                    <li><strong>3. Post específico:</strong> <code>/posts/{id}</code></li>
                    <li><strong>4. Categorías:</strong> <code>/categories</code></li>
                    <li><strong>5. Tags:</strong> <code>/tags</code></li>
                    <li><strong>6. Idiomas:</strong> <code>/languages</code></li>
                </ul>
            </div>
            <div>
                <h3>📊 Análisis y SEO</h3>
                <ul>
                    <li><strong>7. Stats SEO:</strong> <code>/seo-stats</code></li>
                    <li><strong>8. Análisis contenido:</strong> <code>/content-analysis/{id}</code></li>
                    <li><strong>9. Top performing:</strong> <code>/top-performing</code></li>
                    <li><strong>10. Necesita mejora:</strong> <code>/needs-improvement</code></li>
                    <li><strong>11. Stats del sitio:</strong> <code>/site-stats</code></li>
                    <li><strong>12. Focus keywords:</strong> <code>/focus-keywords</code></li>
                </ul>
            </div>
        </div>
        
        <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <h3>🆕 Nuevo para Polylang FREE</h3>
            <ul>
                <li><strong>13. Crear multiidioma:</strong> <code>/create-multilingual-post</code></li>
                <li><strong>14. Obtener traducciones:</strong> <code>/get-translations/{id}</code></li>
                <li><strong>15. Relacionar posts:</strong> <code>/link-translations</code></li>
            </ul>
        </div>
        
        <h2>Probar API</h2>
        <p>
            <a href="<?php echo rest_url('content-search/v1/search?query=test'); ?>" target="_blank" class="button">
                Probar Endpoint de Búsqueda
            </a>
        </p>
    </div>
    <?php
}
