<?php
/**
 * Content Search API - Search Endpoints
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Search {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Register routes
     */
    public function register_routes() {
        $namespace = CSA_Core::get_api_namespace();
        
        // Search content endpoint
        register_rest_route($namespace, '/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_content'),
            'permission_callback' => '__return_true',
            'args' => array(
                'query' => array(
                    'required' => true,
                    'type' => 'string',
                    'description' => 'Término de búsqueda'
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10,
                    'minimum' => 1,
                    'maximum' => 50
                ),
                'post_type' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'post'
                ),
                'language' => array(
                    'required' => false,
                    'type' => 'string',
                    'description' => 'Código de idioma (es, en, fr, etc.)'
                )
            )
        ));
        
        // Advanced search endpoint
        register_rest_route($namespace, '/advanced-search', array(
            'methods' => 'POST',
            'callback' => array($this, 'advanced_search'),
            'permission_callback' => '__return_true',
            'args' => array(
                'query' => array('required' => true, 'type' => 'string'),
                'filters' => array('required' => false, 'type' => 'object'),
                'sort' => array('required' => false, 'type' => 'string', 'default' => 'relevance')
            )
        ));
    }
    
    /**
     * Search content
     */
    public function search_content($request) {
        $query = sanitize_text_field($request->get_param('query'));
        $limit = intval($request->get_param('limit'));
        $post_type = sanitize_text_field($request->get_param('post_type'));
        $language = sanitize_text_field($request->get_param('language'));
        
        if (empty($query)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Query parameter is required'
            ), 400);
        }
        
        // Build WP_Query args
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            's' => $query,
            'meta_query' => array(),
            'orderby' => 'relevance date',
            'order' => 'DESC'
        );
        
        // Add language filter for Polylang
        if (!empty($language) && function_exists('pll_get_post_language')) {
            $args['lang'] = $language;
        }
        
        // Execute search
        $search_query = new WP_Query($args);
        $results = array();
        
        if ($search_query->have_posts()) {
            while ($search_query->have_posts()) {
                $search_query->the_post();
                $post_id = get_the_ID();
                
                $result = array(
                    'id' => $post_id,
                    'title' => get_the_title(),
                    'excerpt' => $this->get_smart_excerpt($post_id, $query),
                    'url' => get_permalink(),
                    'date' => get_the_date('c'),
                    'author' => get_the_author(),
                    'categories' => $this->get_post_categories($post_id),
                    'tags' => $this->get_post_tags($post_id),
                    'featured_image' => $this->get_featured_image($post_id),
                    'relevance_score' => $this->calculate_relevance_score($post_id, $query)
                );
                
                // Add language info if Polylang is active
                if (function_exists('pll_get_post_language')) {
                    $result['language'] = pll_get_post_language($post_id);
                }
                
                // Add Yoast SEO data if available
                $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post_id);
                if ($yoast_data) {
                    $result['seo'] = $yoast_data;
                }
                
                $results[] = $result;
            }
            wp_reset_postdata();
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => $search_query->found_posts,
            'results' => $results,
            'query_info' => array(
                'query' => $query,
                'language' => $language,
                'post_type' => $post_type,
                'execution_time' => $this->get_execution_time()
            )
        ), 200);
    }
    
    /**
     * Advanced search with filters
     */
    public function advanced_search($request) {
        $query = sanitize_text_field($request->get_param('query'));
        $filters = $request->get_param('filters') ?: array();
        $sort = sanitize_text_field($request->get_param('sort'));
        
        // Build complex query based on filters
        $args = array(
            'post_type' => isset($filters['post_type']) ? $filters['post_type'] : 'post',
            'post_status' => 'publish',
            's' => $query,
            'posts_per_page' => isset($filters['limit']) ? intval($filters['limit']) : 10
        );
        
        // Date range filter
        if (isset($filters['date_from']) || isset($filters['date_to'])) {
            $date_query = array();
            if (isset($filters['date_from'])) {
                $date_query['after'] = $filters['date_from'];
            }
            if (isset($filters['date_to'])) {
                $date_query['before'] = $filters['date_to'];
            }
            $args['date_query'] = array($date_query);
        }
        
        // Category filter
        if (isset($filters['categories']) && !empty($filters['categories'])) {
            $args['category__in'] = array_map('intval', $filters['categories']);
        }
        
        // Tag filter
        if (isset($filters['tags']) && !empty($filters['tags'])) {
            $args['tag__in'] = array_map('intval', $filters['tags']);
        }
        
        // Author filter
        if (isset($filters['author'])) {
            $args['author'] = intval($filters['author']);
        }
        
        // Sorting
        switch ($sort) {
            case 'date_desc':
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
                break;
            case 'date_asc':
                $args['orderby'] = 'date';
                $args['order'] = 'ASC';
                break;
            case 'title':
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
            case 'relevance':
            default:
                $args['orderby'] = 'relevance';
                break;
        }
        
        // Execute search
        $search_query = new WP_Query($args);
        $results = array();
        
        if ($search_query->have_posts()) {
            while ($search_query->have_posts()) {
                $search_query->the_post();
                $post_id = get_the_ID();
                
                $results[] = array(
                    'id' => $post_id,
                    'title' => get_the_title(),
                    'excerpt' => $this->get_smart_excerpt($post_id, $query),
                    'url' => get_permalink(),
                    'date' => get_the_date('c'),
                    'author' => get_the_author(),
                    'categories' => $this->get_post_categories($post_id),
                    'tags' => $this->get_post_tags($post_id),
                    'featured_image' => $this->get_featured_image($post_id),
                    'relevance_score' => $this->calculate_relevance_score($post_id, $query)
                );
            }
            wp_reset_postdata();
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => $search_query->found_posts,
            'results' => $results,
            'filters_applied' => $filters,
            'sort' => $sort
        ), 200);
    }
    
    /**
     * Get smart excerpt with highlighted search terms
     */
    private function get_smart_excerpt($post_id, $search_query, $length = 150) {
        $content = get_post_field('post_content', $post_id);
        $content = wp_strip_all_tags($content);
        
        // Try to find the search term in content
        $search_pos = stripos($content, $search_query);
        
        if ($search_pos !== false) {
            // Extract text around the search term
            $start = max(0, $search_pos - 50);
            $excerpt = substr($content, $start, $length);
            
            // Highlight search terms
            $excerpt = preg_replace('/(' . preg_quote($search_query, '/') . ')/i', '<mark>$1</mark>', $excerpt);
            
            return $excerpt . '...';
        }
        
        // Fallback to regular excerpt
        return wp_trim_words($content, 25);
    }
    
    /**
     * Get post categories
     */
    private function get_post_categories($post_id) {
        $categories = get_the_category($post_id);
        $result = array();
        
        foreach ($categories as $category) {
            $result[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug
            );
        }
        
        return $result;
    }
    
    /**
     * Get post tags
     */
    private function get_post_tags($post_id) {
        $tags = get_the_tags($post_id);
        $result = array();
        
        if ($tags) {
            foreach ($tags as $tag) {
                $result[] = array(
                    'id' => $tag->term_id,
                    'name' => $tag->name,
                    'slug' => $tag->slug
                );
            }
        }
        
        return $result;
    }
    
    /**
     * Get featured image
     */
    private function get_featured_image($post_id) {
        $image_id = get_post_thumbnail_id($post_id);
        
        if ($image_id) {
            return array(
                'id' => $image_id,
                'url' => get_the_post_thumbnail_url($post_id, 'medium'),
                'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true)
            );
        }
        
        return null;
    }
    
    /**
     * Calculate relevance score
     */
    private function calculate_relevance_score($post_id, $query) {
        $score = 0;
        $title = get_the_title($post_id);
        $content = get_post_field('post_content', $post_id);
        
        // Title match (higher weight)
        if (stripos($title, $query) !== false) {
            $score += 10;
        }
        
        // Content matches
        $content_matches = substr_count(strtolower($content), strtolower($query));
        $score += $content_matches * 2;
        
        // Recent posts get slight boost
        $days_old = (time() - get_post_time('U', false, $post_id)) / DAY_IN_SECONDS;
        if ($days_old < 30) {
            $score += 2;
        }
        
        return min($score, 100); // Cap at 100
    }
    
    /**
     * Get execution time (placeholder)
     */
    private function get_execution_time() {
        return round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 3);
    }
}
