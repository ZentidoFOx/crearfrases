<?php
/**
 * Content Search API - Polylang Multilingual Endpoints
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Polylang {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Register routes
     */
    public function register_routes() {
        $namespace = CSA_Core::get_api_namespace();
        
        // 🆕 NUEVO: Endpoint especial para Polylang FREE
        register_rest_route($namespace, '/create-multilingual-post', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_multilingual_post'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'posts' => array(
                    'required' => true,
                    'type' => 'array',
                    'description' => 'Array de posts por idioma'
                ),
                'main_language' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'es'
                )
            )
        ));
        
        // Endpoint para obtener traducciones existentes
        register_rest_route($namespace, '/get-translations/(?P<post_id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_post_translations'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint para relacionar posts existentes
        register_rest_route($namespace, '/link-translations', array(
            'methods' => 'POST',
            'callback' => array($this, 'link_existing_posts'),
            'permission_callback' => array($this, 'check_permission'),
        ));
    }
    
    /**
     * 🚀 NUEVO: Crear post multiidioma con relaciones automáticas
     * Funciona con Polylang FREE y PREMIUM
     */
    public function create_multilingual_post($request) {
        $posts_data = $request->get_param('posts');
        $main_language = $request->get_param('main_language');
        
        if (empty($posts_data) || !is_array($posts_data)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Posts data is required and must be an array'
            ), 400);
        }
        
        // Verificar que Polylang esté activo
        if (!function_exists('pll_set_post_language')) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Polylang plugin is not active'
            ), 400);
        }
        
        $created_posts = array();
        $translation_group = array();
        
        try {
            // PASO 1: Crear todos los posts individualmente
            foreach ($posts_data as $lang_code => $post_data) {
                $post_id = $this->create_single_post($post_data, $lang_code);
                
                if (is_wp_error($post_id)) {
                    throw new Exception("Error creating post for language {$lang_code}: " . $post_id->get_error_message());
                }
                
                $created_posts[$lang_code] = $post_id;
                $translation_group[$lang_code] = $post_id;
                
                // Configurar idioma del post
                pll_set_post_language($post_id, $lang_code);
                
                // Configurar Yoast SEO si está disponible
                if (isset($post_data['yoast_seo']) && class_exists('CSA_Yoast')) {
                    CSA_Yoast::get_instance()->set_yoast_data($post_id, $post_data['yoast_seo']);
                }
            }
            
            // PASO 2: Relacionar todos los posts entre sí
            if (count($translation_group) > 1) {
                $this->create_translation_relationships($translation_group);
            }
            
            // PASO 3: Obtener datos completos de los posts creados
            $complete_posts = array();
            foreach ($created_posts as $lang_code => $post_id) {
                $complete_posts[$lang_code] = $this->get_complete_post_data($post_id);
            }
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Multilingual posts created and linked successfully',
                'posts' => $complete_posts,
                'translation_group' => $translation_group,
                'main_language' => $main_language,
                'polylang_version' => $this->get_polylang_version()
            ), 201);
            
        } catch (Exception $e) {
            // Si algo falla, intentar limpiar posts creados
            foreach ($created_posts as $post_id) {
                wp_delete_post($post_id, true);
            }
            
            return new WP_REST_Response(array(
                'success' => false,
                'error' => $e->getMessage()
            ), 500);
        }
    }
    
    /**
     * Crear un post individual
     */
    private function create_single_post($post_data, $lang_code) {
        // Preparar datos del post
        $wp_post_data = array(
            'post_title' => sanitize_text_field($post_data['title']),
            'post_content' => wp_kses_post($post_data['content']),
            'post_status' => isset($post_data['status']) ? $post_data['status'] : 'publish',
            'post_type' => isset($post_data['post_type']) ? $post_data['post_type'] : 'post',
            'post_author' => isset($post_data['author_id']) ? intval($post_data['author_id']) : get_current_user_id(),
            'meta_input' => array()
        );
        
        // Agregar excerpt si está disponible
        if (isset($post_data['excerpt'])) {
            $wp_post_data['post_excerpt'] = sanitize_textarea_field($post_data['excerpt']);
        }
        
        // Crear el post
        $post_id = wp_insert_post($wp_post_data);
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        // Configurar categorías
        if (isset($post_data['categories']) && !empty($post_data['categories'])) {
            $category_ids = $this->process_categories($post_data['categories'], $lang_code);
            wp_set_post_categories($post_id, $category_ids);
        }
        
        // Configurar tags
        if (isset($post_data['tags']) && !empty($post_data['tags'])) {
            $tag_ids = $this->process_tags($post_data['tags'], $lang_code);
            wp_set_post_tags($post_id, $tag_ids);
        }
        
        // Configurar imagen destacada
        if (isset($post_data['featured_image_id'])) {
            set_post_thumbnail($post_id, intval($post_data['featured_image_id']));
        }
        
        // Metadatos personalizados
        if (isset($post_data['meta']) && is_array($post_data['meta'])) {
            foreach ($post_data['meta'] as $key => $value) {
                update_post_meta($post_id, sanitize_key($key), $value);
            }
        }
        
        return $post_id;
    }
    
    /**
     * Crear relaciones entre traducciones
     * Funciona tanto en Polylang FREE como PREMIUM
     */
    private function create_translation_relationships($translation_group) {
        // Método 1: Usar pll_save_post_translations (funciona en FREE y PREMIUM)
        if (function_exists('pll_save_post_translations')) {
            pll_save_post_translations($translation_group);
            return true;
        }
        
        // Método 2: Fallback para versiones muy antiguas
        if (function_exists('pll_set_post_translations')) {
            foreach ($translation_group as $lang_code => $post_id) {
                pll_set_post_translations($post_id, $translation_group);
            }
            return true;
        }
        
        // Método 3: Fallback manual usando la base de datos
        return $this->create_translations_manually($translation_group);
    }
    
    /**
     * Crear relaciones manualmente (último recurso)
     */
    private function create_translations_manually($translation_group) {
        global $wpdb;
        
        try {
            // Obtener el próximo translation group ID
            $trid = $wpdb->get_var("SELECT MAX(trid) FROM {$wpdb->prefix}icl_translations") + 1;
            
            foreach ($translation_group as $lang_code => $post_id) {
                // Verificar si ya existe una entrada
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT translation_id FROM {$wpdb->prefix}icl_translations WHERE element_id = %d AND element_type = 'post_post'",
                    $post_id
                ));
                
                if (!$existing) {
                    $wpdb->insert(
                        $wpdb->prefix . 'icl_translations',
                        array(
                            'element_type' => 'post_post',
                            'element_id' => $post_id,
                            'trid' => $trid,
                            'language_code' => $lang_code,
                            'source_language_code' => null
                        ),
                        array('%s', '%d', '%d', '%s', '%s')
                    );
                }
            }
            
            return true;
            
        } catch (Exception $e) {
            error_log('CSA Polylang: Error creating manual translations: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Procesar categorías para un idioma específico
     */
    private function process_categories($categories, $lang_code) {
        $category_ids = array();
        
        foreach ($categories as $category) {
            if (is_numeric($category)) {
                // Es un ID de categoría
                $category_ids[] = intval($category);
            } else {
                // Es un nombre de categoría, buscar o crear
                $term = get_term_by('name', $category, 'category');
                
                if ($term) {
                    $category_ids[] = $term->term_id;
                } else {
                    // Crear nueva categoría
                    $new_term = wp_insert_term($category, 'category');
                    if (!is_wp_error($new_term)) {
                        $category_ids[] = $new_term['term_id'];
                        
                        // Configurar idioma de la categoría si Polylang está activo
                        if (function_exists('pll_set_term_language')) {
                            pll_set_term_language($new_term['term_id'], $lang_code);
                        }
                    }
                }
            }
        }
        
        return $category_ids;
    }
    
    /**
     * Procesar tags para un idioma específico
     */
    private function process_tags($tags, $lang_code) {
        $tag_ids = array();
        
        foreach ($tags as $tag) {
            if (is_numeric($tag)) {
                $tag_ids[] = intval($tag);
            } else {
                $term = get_term_by('name', $tag, 'post_tag');
                
                if ($term) {
                    $tag_ids[] = $term->term_id;
                } else {
                    $new_term = wp_insert_term($tag, 'post_tag');
                    if (!is_wp_error($new_term)) {
                        $tag_ids[] = $new_term['term_id'];
                        
                        if (function_exists('pll_set_term_language')) {
                            pll_set_term_language($new_term['term_id'], $lang_code);
                        }
                    }
                }
            }
        }
        
        return $tag_ids;
    }
    
    /**
     * Obtener datos completos del post
     */
    private function get_complete_post_data($post_id) {
        $post = get_post($post_id);
        
        if (!$post) {
            return null;
        }
        
        $data = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'status' => $post->post_status,
            'url' => get_permalink($post_id),
            'date' => $post->post_date,
            'modified' => $post->post_modified,
            'author' => get_the_author_meta('display_name', $post->post_author)
        );
        
        // Agregar idioma si Polylang está activo
        if (function_exists('pll_get_post_language')) {
            $data['language'] = pll_get_post_language($post_id);
        }
        
        // Agregar traducciones relacionadas
        if (function_exists('pll_get_post_translations')) {
            $data['translations'] = pll_get_post_translations($post_id);
        }
        
        // Agregar datos de Yoast SEO
        if (class_exists('CSA_Yoast')) {
            $data['yoast_seo'] = CSA_Yoast::get_instance()->get_yoast_data($post_id);
        }
        
        return $data;
    }
    
    /**
     * Obtener traducciones de un post
     */
    public function get_post_translations($request) {
        $post_id = intval($request['post_id']);
        
        if (!function_exists('pll_get_post_translations')) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Polylang is not active'
            ), 400);
        }
        
        $translations = pll_get_post_translations($post_id);
        $complete_translations = array();
        
        foreach ($translations as $lang_code => $translation_id) {
            $complete_translations[$lang_code] = $this->get_complete_post_data($translation_id);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'post_id' => $post_id,
            'translations' => $complete_translations
        ), 200);
    }
    
    /**
     * Relacionar posts existentes
     */
    public function link_existing_posts($request) {
        $posts = $request->get_param('posts');
        
        if (empty($posts) || !is_array($posts)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Posts array is required'
            ), 400);
        }
        
        $success = $this->create_translation_relationships($posts);
        
        return new WP_REST_Response(array(
            'success' => $success,
            'message' => $success ? 'Posts linked successfully' : 'Failed to link posts',
            'linked_posts' => $posts
        ), $success ? 200 : 500);
    }
    
    /**
     * Check permission for write operations
     */
    public function check_permission() {
        return current_user_can('edit_posts');
    }
    
    /**
     * Get Polylang version info
     */
    private function get_polylang_version() {
        if (defined('POLYLANG_VERSION')) {
            return array(
                'version' => POLYLANG_VERSION,
                'is_pro' => defined('POLYLANG_PRO'),
                'has_rest_api' => function_exists('pll_save_post_translations')
            );
        }
        
        return array(
            'version' => 'unknown',
            'is_pro' => false,
            'has_rest_api' => false
        );
    }
}
