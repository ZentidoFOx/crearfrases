<?php
/**
 * Content Search API - Posts Management Endpoints
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Posts {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Register routes
     */
    public function register_routes() {
        $namespace = CSA_Core::get_api_namespace();
        
        // Endpoint 2: Obtener posts/páginas
        register_rest_route($namespace, '/posts', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_posts'),
            'permission_callback' => '__return_true',
            'args' => array(
                'per_page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10,
                    'minimum' => 1,
                    'maximum' => 100
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                    'minimum' => 1
                ),
                'post_type' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'post'
                ),
                'language' => array(
                    'required' => false,
                    'type' => 'string',
                    'description' => 'Código de idioma para Polylang'
                )
            )
        ));
        
        // Endpoint 3: Obtener post específico
        register_rest_route($namespace, '/posts/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_post'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 4: Obtener categorías
        register_rest_route($namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 5: Obtener tags
        register_rest_route($namespace, '/tags', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_tags'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 6: Obtener idiomas disponibles
        register_rest_route($namespace, '/languages', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_languages'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 7: Obtener estadísticas de calidad SEO
        register_rest_route($namespace, '/seo-stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_seo_stats'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 8: Análisis detallado de contenido
        register_rest_route($namespace, '/content-analysis/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'content_analysis'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 9: Posts con mejor rendimiento
        register_rest_route($namespace, '/top-performing', array(
            'methods' => 'GET',
            'callback' => array($this, 'top_performing'),
            'permission_callback' => '__return_true',
            'args' => array(
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10,
                    'minimum' => 1,
                    'maximum' => 50
                )
            )
        ));
        
        // Endpoint 10: Posts que necesitan mejora
        register_rest_route($namespace, '/needs-improvement', array(
            'methods' => 'GET',
            'callback' => array($this, 'needs_improvement'),
            'permission_callback' => '__return_true',
            'args' => array(
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10
                )
            )
        ));
        
        // Endpoint 11: Estadísticas globales del sitio
        register_rest_route($namespace, '/site-stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'site_stats'),
            'permission_callback' => '__return_true',
        ));
        
        // Endpoint 12: Buscar por Frase Clave Objetivo (Yoast Focus Keyword)
        register_rest_route($namespace, '/focus-keywords', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_focus_keywords'),
            'permission_callback' => '__return_true',
            'args' => array(
                'keyword' => array(
                    'required' => true,
                    'type' => 'string',
                    'description' => 'Palabra clave a buscar'
                )
            )
        ));
        
        // Track post view
        register_rest_route($namespace, '/track-view/(?P<id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'track_post_view'),
            'permission_callback' => '__return_true',
        ));
    }
    
    /**
     * Get single post with complete data
     */
    public function get_post($request) {
        $post_id = intval($request['id']);
        $post = get_post($post_id);
        
        if (!$post || $post->post_status !== 'publish') {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Post not found or not published'
            ), 404);
        }
        
        // Track view
        CSA_Analytics::get_instance()->increment_post_views($post_id);
        
        // Build complete post data
        $post_data = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => apply_filters('the_content', $post->post_content),
            'excerpt' => $post->post_excerpt,
            'date' => $post->post_date,
            'modified' => $post->post_modified,
            'author' => get_the_author_meta('display_name', $post->post_author),
            'url' => get_permalink($post_id),
            'featured_image' => $this->get_featured_image_data($post_id),
            'categories' => $this->get_post_categories($post_id),
            'tags' => $this->get_post_tags($post_id),
            'views' => CSA_Analytics::get_instance()->get_post_views($post_id),
            'word_count' => str_word_count(strip_tags($post->post_content)),
            'reading_time' => $this->calculate_reading_time($post->post_content)
        );
        
        // Add Yoast SEO data
        $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post_id);
        if ($yoast_data) {
            $post_data['yoast_seo'] = $yoast_data;
        }
        
        // Add Polylang data
        if (function_exists('pll_get_post_language')) {
            $post_data['language'] = pll_get_post_language($post_id);
            $post_data['translations'] = pll_get_post_translations($post_id);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $post_data,
        ), 200);
    }
    
    /**
     * Get categories
     */
    public function get_categories($request) {
        $categories = get_categories(array(
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        $results = array();
        foreach ($categories as $category) {
            $cat_data = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
                'count' => $category->count,
                'description' => $category->description,
                'url' => get_category_link($category->term_id),
            );
            
            // Add Polylang language info
            if (function_exists('pll_get_term_language')) {
                $cat_data['language'] = pll_get_term_language($category->term_id);
            }
            
            $results[] = $cat_data;
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => count($results),
            'data' => $results,
        ), 200);
    }
    
    /**
     * Get tags
     */
    public function get_tags($request) {
        $tags = get_tags(array(
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        $results = array();
        foreach ($tags as $tag) {
            $tag_data = array(
                'id' => $tag->term_id,
                'name' => $tag->name,
                'slug' => $tag->slug,
                'count' => $tag->count,
                'description' => $tag->description,
                'url' => get_tag_link($tag->term_id),
            );
            
            // Add Polylang language info
            if (function_exists('pll_get_term_language')) {
                $tag_data['language'] = pll_get_term_language($tag->term_id);
            }
            
            $results[] = $tag_data;
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => count($results),
            'data' => $results,
        ), 200);
    }
    
    /**
     * Track post view
     */
    public function track_post_view($request) {
        $post_id = intval($request['id']);
        
        if (!get_post($post_id)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Post not found'
            ), 404);
        }
        
        $new_count = CSA_Analytics::get_instance()->increment_post_views($post_id);
        
        return new WP_REST_Response(array(
            'success' => true,
            'post_id' => $post_id,
            'views' => $new_count
        ), 200);
    }
    
    /**
     * Get featured image data
     */
    private function get_featured_image_data($post_id) {
        $image_id = get_post_thumbnail_id($post_id);
        
        if (!$image_id) {
            return null;
        }
        
        return array(
            'id' => $image_id,
            'url' => get_the_post_thumbnail_url($post_id, 'full'),
            'medium' => get_the_post_thumbnail_url($post_id, 'medium'),
            'thumbnail' => get_the_post_thumbnail_url($post_id, 'thumbnail'),
            'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
            'caption' => wp_get_attachment_caption($image_id)
        );
    }
    
    /**
     * Get post categories
     */
    private function get_post_categories($post_id) {
        $categories = get_the_category($post_id);
        $result = array();
        
        foreach ($categories as $category) {
            $result[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
                'url' => get_category_link($category->term_id)
            );
        }
        
        return $result;
    }
    
    /**
     * Get post tags
     */
    private function get_post_tags($post_id) {
        $tags = get_the_tags($post_id);
        $result = array();
        
        if ($tags) {
            foreach ($tags as $tag) {
                $result[] = array(
                    'id' => $tag->term_id,
                    'name' => $tag->name,
                    'slug' => $tag->slug,
                    'url' => get_tag_link($tag->term_id)
                );
            }
        }
        
        return $result;
    }
    
    /**
     * Get posts with pagination
     */
    public function get_posts($request) {
        $per_page = intval($request->get_param('per_page'));
        $page = intval($request->get_param('page'));
        $post_type = sanitize_text_field($request->get_param('post_type'));
        $language = sanitize_text_field($request->get_param('language'));
        
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        // Add language filter for Polylang
        if (!empty($language) && function_exists('pll_get_post_language')) {
            $args['lang'] = $language;
        }
        
        $query = new WP_Query($args);
        $posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();
                
                $posts[] = array(
                    'id' => $post_id,
                    'title' => get_the_title(),
                    'excerpt' => get_the_excerpt(),
                    'url' => get_permalink(),
                    'date' => get_the_date('c'),
                    'author' => get_the_author(),
                    'featured_image' => $this->get_featured_image_data($post_id),
                    'categories' => $this->get_post_categories($post_id),
                    'tags' => $this->get_post_tags($post_id),
                    'views' => CSA_Analytics::get_instance()->get_post_views($post_id),
                    'language' => function_exists('pll_get_post_language') ? pll_get_post_language($post_id) : null
                );
            }
            wp_reset_postdata();
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'current_page' => $page,
            'per_page' => $per_page,
            'data' => $posts
        ), 200);
    }
    
    /**
     * Get languages
     */
    public function get_languages($request) {
        if (!function_exists('pll_languages_list')) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Polylang plugin is not active'
            ), 400);
        }
        
        $languages = pll_languages_list(array('fields' => 'names'));
        $language_data = array();
        
        foreach ($languages as $code => $name) {
            $language_data[] = array(
                'code' => $code,
                'name' => $name,
                'url' => pll_home_url($code),
                'is_default' => pll_default_language() === $code
            );
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => count($language_data),
            'data' => $language_data
        ), 200);
    }
    
    /**
     * Get SEO stats
     */
    public function get_seo_stats($request) {
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1
        ));
        
        $stats = array(
            'total_posts' => count($posts),
            'with_yoast_data' => 0,
            'excellent_seo' => 0,
            'good_seo' => 0,
            'needs_improvement' => 0,
            'poor_seo' => 0,
            'avg_seo_score' => 0,
            'avg_readability_score' => 0
        );
        
        $total_seo_score = 0;
        $total_readability_score = 0;
        
        foreach ($posts as $post) {
            $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post->ID);
            
            if ($yoast_data) {
                $stats['with_yoast_data']++;
                
                $seo_score = intval($yoast_data['seo_score']);
                $readability_score = intval($yoast_data['readability_score']);
                
                $total_seo_score += $seo_score;
                $total_readability_score += $readability_score;
                
                if ($seo_score >= 70 && $readability_score >= 60) {
                    $stats['excellent_seo']++;
                } elseif ($seo_score >= 50 && $readability_score >= 40) {
                    $stats['good_seo']++;
                } elseif ($seo_score >= 30 || $readability_score >= 30) {
                    $stats['needs_improvement']++;
                } else {
                    $stats['poor_seo']++;
                }
            }
        }
        
        if ($stats['with_yoast_data'] > 0) {
            $stats['avg_seo_score'] = round($total_seo_score / $stats['with_yoast_data'], 1);
            $stats['avg_readability_score'] = round($total_readability_score / $stats['with_yoast_data'], 1);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $stats
        ), 200);
    }
    
    /**
     * Content analysis
     */
    public function content_analysis($request) {
        $post_id = intval($request['id']);
        $post = get_post($post_id);
        
        if (!$post) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Post not found'
            ), 404);
        }
        
        $content = $post->post_content;
        $title = $post->post_title;
        
        $analysis = array(
            'word_count' => str_word_count(strip_tags($content)),
            'char_count' => strlen(strip_tags($content)),
            'paragraph_count' => substr_count($content, '</p>'),
            'heading_count' => substr_count($content, '</h') + substr_count($content, '</H'),
            'image_count' => substr_count($content, '<img'),
            'link_count' => substr_count($content, '<a '),
            'list_count' => substr_count($content, '<ul') + substr_count($content, '<ol'),
            'reading_time_minutes' => ceil(str_word_count(strip_tags($content)) / 200)
        );
        
        // Add Yoast SEO data
        $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post_id);
        if ($yoast_data) {
            $analysis['yoast_seo'] = $yoast_data;
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'post_id' => $post_id,
            'data' => $analysis
        ), 200);
    }
    
    /**
     * Top performing posts
     */
    public function top_performing($request) {
        $limit = intval($request->get_param('limit'));
        
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_key' => '_csa_post_views',
            'orderby' => 'meta_value_num',
            'order' => 'DESC'
        );
        
        $posts = get_posts($args);
        $results = array();
        
        foreach ($posts as $post) {
            $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post->ID);
            
            $results[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'url' => get_permalink($post->ID),
                'views' => CSA_Analytics::get_instance()->get_post_views($post->ID),
                'date' => $post->post_date,
                'yoast_seo' => $yoast_data
            );
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => count($results),
            'data' => $results
        ), 200);
    }
    
    /**
     * Posts that need improvement
     */
    public function needs_improvement($request) {
        $limit = intval($request->get_param('limit'));
        
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1
        ));
        
        $needs_improvement = array();
        
        foreach ($posts as $post) {
            $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post->ID);
            
            if ($yoast_data) {
                $seo_score = intval($yoast_data['seo_score']);
                $readability_score = intval($yoast_data['readability_score']);
                
                // Posts with low scores need improvement
                if ($seo_score < 50 || $readability_score < 40) {
                    $needs_improvement[] = array(
                        'id' => $post->ID,
                        'title' => $post->post_title,
                        'url' => get_permalink($post->ID),
                        'seo_score' => $seo_score,
                        'readability_score' => $readability_score,
                        'yoast_seo' => $yoast_data
                    );
                }
            }
        }
        
        // Sort by worst scores first
        usort($needs_improvement, function($a, $b) {
            return ($a['seo_score'] + $a['readability_score']) - ($b['seo_score'] + $b['readability_score']);
        });
        
        // Limit results
        if ($limit > 0) {
            $needs_improvement = array_slice($needs_improvement, 0, $limit);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'total' => count($needs_improvement),
            'data' => $needs_improvement
        ), 200);
    }
    
    /**
     * Site stats
     */
    public function site_stats($request) {
        $stats = array(
            'total_posts' => wp_count_posts('post')->publish,
            'total_pages' => wp_count_posts('page')->publish,
            'total_categories' => wp_count_terms('category'),
            'total_tags' => wp_count_terms('post_tag'),
            'total_views' => 0,
            'avg_views_per_post' => 0
        );
        
        // Calculate total views
        global $wpdb;
        $total_views = $wpdb->get_var(
            "SELECT SUM(meta_value) FROM {$wpdb->postmeta} WHERE meta_key = '_csa_post_views'"
        );
        
        $stats['total_views'] = intval($total_views);
        $stats['avg_views_per_post'] = $stats['total_posts'] > 0 ? 
            round($stats['total_views'] / $stats['total_posts'], 1) : 0;
        
        // Add language stats if Polylang is active
        if (function_exists('pll_languages_list')) {
            $languages = pll_languages_list();
            $stats['languages'] = count($languages);
            $stats['language_codes'] = $languages;
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $stats
        ), 200);
    }
    
    /**
     * Search focus keywords
     */
    public function search_focus_keywords($request) {
        $keyword = sanitize_text_field($request->get_param('keyword'));
        
        if (empty($keyword)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Keyword parameter is required'
            ), 400);
        }
        
        global $wpdb;
        
        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, pm.meta_value as focus_keyword 
             FROM {$wpdb->posts} p 
             JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id 
             WHERE pm.meta_key = '_yoast_wpseo_focuskw' 
             AND pm.meta_value LIKE %s 
             AND p.post_status = 'publish'",
            '%' . $keyword . '%'
        ));
        
        $results = array();
        
        foreach ($posts as $post) {
            $yoast_data = CSA_Yoast::get_instance()->get_yoast_data($post->ID);
            
            $results[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'focus_keyword' => $post->focus_keyword,
                'url' => get_permalink($post->ID),
                'yoast_seo' => $yoast_data
            );
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'keyword' => $keyword,
            'total' => count($results),
            'data' => $results
        ), 200);
    }
    
    /**
     * Calculate reading time
     */
    private function calculate_reading_time($content) {
        $word_count = str_word_count(strip_tags($content));
        $minutes = ceil($word_count / 200); // Average reading speed: 200 words per minute
        
        return array(
            'minutes' => $minutes,
            'text' => sprintf(_n('%d minuto', '%d minutos', $minutes, 'content-search-api'), $minutes)
        );
    }
}
