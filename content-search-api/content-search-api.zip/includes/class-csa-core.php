<?php
/**
 * Content Search API - Core Class
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Core {
    
    /**
     * Plugin version
     */
    const VERSION = '2.1.0';
    
    /**
     * API namespace
     */
    const API_NAMESPACE = 'content-search/v1';
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        // Load endpoint classes
        require_once CSA_PLUGIN_DIR . 'includes/endpoints/class-csa-search.php';
        require_once CSA_PLUGIN_DIR . 'includes/endpoints/class-csa-posts.php';
        require_once CSA_PLUGIN_DIR . 'includes/endpoints/class-csa-polylang.php';
        
        // Load integration classes
        require_once CSA_PLUGIN_DIR . 'includes/integrations/class-csa-yoast.php';
        require_once CSA_PLUGIN_DIR . 'includes/integrations/class-csa-polylang-integration.php';
        
        // Load utility classes
        require_once CSA_PLUGIN_DIR . 'includes/utils/class-csa-helpers.php';
        require_once CSA_PLUGIN_DIR . 'includes/utils/class-csa-analytics.php';
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Initialize endpoint classes
        CSA_Search::get_instance()->register_routes();
        CSA_Posts::get_instance()->register_routes();
        CSA_Polylang::get_instance()->register_routes();
    }
    
    /**
     * Enqueue scripts
     */
    public function enqueue_scripts() {
        // Only enqueue on frontend if needed
        if (!is_admin()) {
            wp_enqueue_script(
                'csa-analytics',
                CSA_PLUGIN_URL . 'assets/js/analytics.js',
                array('jquery'),
                self::VERSION,
                true
            );
            
            wp_localize_script('csa-analytics', 'csa_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('csa_nonce'),
                'api_url' => rest_url(self::API_NAMESPACE)
            ));
        }
    }
    
    /**
     * Get API namespace
     */
    public static function get_api_namespace() {
        return self::API_NAMESPACE;
    }
    
    /**
     * Plugin activation
     */
    public static function activate() {
        // Create necessary database tables if needed
        self::create_tables();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create plugin tables
     */
    private static function create_tables() {
        global $wpdb;
        
        // Table for post views tracking
        $table_name = $wpdb->prefix . 'csa_post_views';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            views bigint(20) DEFAULT 0,
            last_viewed datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_id (post_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
