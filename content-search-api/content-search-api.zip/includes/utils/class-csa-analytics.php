<?php
/**
 * Content Search API - Analytics and Views Tracking
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Analytics {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get post views
     */
    public function get_post_views($post_id) {
        $views = get_post_meta($post_id, '_csa_post_views', true);
        return $views ? intval($views) : 0;
    }
    
    /**
     * Increment post views
     */
    public function increment_post_views($post_id) {
        $current_views = $this->get_post_views($post_id);
        $new_views = $current_views + 1;
        
        update_post_meta($post_id, '_csa_post_views', $new_views);
        
        // Also update in custom table if exists
        $this->update_views_table($post_id, $new_views);
        
        return $new_views;
    }
    
    /**
     * Update views in custom table
     */
    private function update_views_table($post_id, $views) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'csa_post_views';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return false;
        }
        
        // Insert or update
        $wpdb->replace(
            $table_name,
            array(
                'post_id' => $post_id,
                'views' => $views,
                'last_viewed' => current_time('mysql')
            ),
            array('%d', '%d', '%s')
        );
        
        return true;
    }
    
    /**
     * Get popular posts
     */
    public function get_popular_posts($limit = 10, $days = 30) {
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_key' => '_csa_post_views',
            'orderby' => 'meta_value_num',
            'order' => 'DESC',
            'date_query' => array(
                array(
                    'after' => $days . ' days ago'
                )
            )
        );
        
        $posts = get_posts($args);
        $results = array();
        
        foreach ($posts as $post) {
            $results[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'url' => get_permalink($post->ID),
                'views' => $this->get_post_views($post->ID),
                'date' => $post->post_date
            );
        }
        
        return $results;
    }
    
    /**
     * Get analytics dashboard data
     */
    public function get_dashboard_data() {
        global $wpdb;
        
        // Total posts
        $total_posts = wp_count_posts('post')->publish;
        
        // Total views
        $total_views = $wpdb->get_var("
            SELECT SUM(meta_value) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_csa_post_views'
        ");
        
        // Views today
        $views_today = $this->get_views_by_date(date('Y-m-d'));
        
        // Views this week
        $views_week = $this->get_views_by_date_range(
            date('Y-m-d', strtotime('-7 days')),
            date('Y-m-d')
        );
        
        // Popular posts
        $popular_posts = $this->get_popular_posts(5);
        
        return array(
            'total_posts' => intval($total_posts),
            'total_views' => intval($total_views),
            'views_today' => intval($views_today),
            'views_week' => intval($views_week),
            'popular_posts' => $popular_posts,
            'generated_at' => current_time('c')
        );
    }
    
    /**
     * Get views by specific date
     */
    private function get_views_by_date($date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'csa_post_views';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return 0;
        }
        
        return $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM $table_name 
            WHERE DATE(last_viewed) = %s
        ", $date));
    }
    
    /**
     * Get views by date range
     */
    private function get_views_by_date_range($start_date, $end_date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'csa_post_views';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return 0;
        }
        
        return $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM $table_name 
            WHERE DATE(last_viewed) BETWEEN %s AND %s
        ", $start_date, $end_date));
    }
}
