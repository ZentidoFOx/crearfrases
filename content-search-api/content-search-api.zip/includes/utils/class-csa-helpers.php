<?php
/**
 * Content Search API - Helper Functions
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Helpers {
    
    /**
     * Decode HTML entities
     */
    public static function decode_html_entities($text) {
        return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    /**
     * Sanitize search query
     */
    public static function sanitize_search_query($query) {
        // Remove special characters but keep spaces and basic punctuation
        $query = preg_replace('/[^\p{L}\p{N}\s\-_.,!?]/u', '', $query);
        
        // Trim and normalize spaces
        $query = trim(preg_replace('/\s+/', ' ', $query));
        
        return $query;
    }
    
    /**
     * Extract keywords from text
     */
    public static function extract_keywords($text, $min_length = 3, $max_keywords = 10) {
        // Remove HTML tags and normalize
        $text = strip_tags($text);
        $text = strtolower($text);
        
        // Remove common stop words (Spanish)
        $stop_words = array(
            'el', 'la', 'de', 'que', 'y', 'a', 'en', 'un', 'es', 'se', 'no', 'te', 'lo', 'le',
            'da', 'su', 'por', 'son', 'con', 'para', 'al', 'del', 'los', 'las', 'una', 'como',
            'pero', 'sus', 'le', 'ya', 'o', 'fue', 'este', 'ha', 'si', 'porque', 'esta', 'son',
            'entre', 'cuando', 'muy', 'sin', 'sobre', 'ser', 'tiene', 'también', 'me', 'hasta',
            'hay', 'donde', 'han', 'quien', 'están', 'estado', 'desde', 'todo', 'nos', 'durante',
            'todos', 'uno', 'les', 'ni', 'contra', 'otros', 'fueron', 'ese', 'eso', 'había',
            'ante', 'ellos', 'e', 'esto', 'mí', 'antes', 'algunos', 'qué', 'unos', 'yo', 'otro',
            'otras', 'otra', 'él', 'tanto', 'esa', 'estos', 'mucho', 'quienes', 'nada', 'muchos',
            'cual', 'sea', 'poco', 'ella', 'estar', 'haber', 'estas', 'estaba', 'estamos', 'pueden',
            'hacen', 'cada', 'fin', 'incluso', 'primero', 'además', 'mientras', 'sin', 'caso', 'lugar'
        );
        
        // Extract words
        preg_match_all('/\b\w{' . $min_length . ',}\b/', $text, $matches);
        $words = $matches[0];
        
        // Remove stop words
        $words = array_diff($words, $stop_words);
        
        // Count word frequency
        $word_freq = array_count_values($words);
        
        // Sort by frequency
        arsort($word_freq);
        
        // Return top keywords
        return array_slice(array_keys($word_freq), 0, $max_keywords);
    }
    
    /**
     * Calculate text similarity
     */
    public static function calculate_similarity($text1, $text2) {
        $text1 = strtolower(strip_tags($text1));
        $text2 = strtolower(strip_tags($text2));
        
        // Simple similarity based on common words
        $words1 = explode(' ', $text1);
        $words2 = explode(' ', $text2);
        
        $common_words = array_intersect($words1, $words2);
        $total_words = array_unique(array_merge($words1, $words2));
        
        if (empty($total_words)) {
            return 0;
        }
        
        return (count($common_words) / count($total_words)) * 100;
    }
    
    /**
     * Format file size
     */
    public static function format_file_size($bytes) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }
    
    /**
     * Validate URL
     */
    public static function validate_url($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
    
    /**
     * Generate excerpt with highlighted terms
     */
    public static function generate_highlighted_excerpt($content, $search_terms, $length = 200) {
        $content = strip_tags($content);
        
        // Find the first occurrence of any search term
        $first_pos = false;
        foreach ($search_terms as $term) {
            $pos = stripos($content, $term);
            if ($pos !== false && ($first_pos === false || $pos < $first_pos)) {
                $first_pos = $pos;
            }
        }
        
        if ($first_pos !== false) {
            // Extract text around the found term
            $start = max(0, $first_pos - 50);
            $excerpt = substr($content, $start, $length);
            
            // Highlight search terms
            foreach ($search_terms as $term) {
                $excerpt = preg_replace(
                    '/(' . preg_quote($term, '/') . ')/i',
                    '<mark>$1</mark>',
                    $excerpt
                );
            }
            
            return '...' . $excerpt . '...';
        }
        
        // Fallback to regular excerpt
        return substr($content, 0, $length) . '...';
    }
    
    /**
     * Clean and normalize text
     */
    public static function normalize_text($text) {
        // Remove HTML tags
        $text = strip_tags($text);
        
        // Decode HTML entities
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // Normalize whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        // Trim
        $text = trim($text);
        
        return $text;
    }
    
    /**
     * Generate slug from text
     */
    public static function generate_slug($text, $max_length = 50) {
        // Normalize and clean
        $slug = self::normalize_text($text);
        
        // Convert to lowercase
        $slug = strtolower($slug);
        
        // Replace spaces and special characters with hyphens
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        
        // Remove leading/trailing hyphens
        $slug = trim($slug, '-');
        
        // Limit length
        if (strlen($slug) > $max_length) {
            $slug = substr($slug, 0, $max_length);
            $slug = trim($slug, '-');
        }
        
        return $slug;
    }
    
    /**
     * Check if content contains spam indicators
     */
    public static function is_spam_content($content) {
        $spam_indicators = array(
            'viagra', 'casino', 'poker', 'loan', 'mortgage', 'insurance',
            'weight loss', 'make money', 'work from home', 'click here',
            'free money', 'guaranteed', 'no risk', 'limited time'
        );
        
        $content_lower = strtolower($content);
        
        foreach ($spam_indicators as $indicator) {
            if (strpos($content_lower, $indicator) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get client IP address
     */
    public static function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP, 
                        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
}
