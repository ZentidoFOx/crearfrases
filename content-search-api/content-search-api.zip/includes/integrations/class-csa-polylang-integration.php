<?php
/**
 * Content Search API - Polylang Integration Helper
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Polylang_Integration {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Check if Polylang is active
     */
    public function is_polylang_active() {
        return function_exists('pll_languages_list');
    }
    
    /**
     * Check if Polylang Pro is active
     */
    public function is_polylang_pro() {
        return defined('POLYLANG_PRO') && POLYLANG_PRO;
    }
    
    /**
     * Get available languages
     */
    public function get_languages() {
        if (!$this->is_polylang_active()) {
            return array();
        }
        
        $languages = pll_languages_list(array('fields' => 'names'));
        $language_data = array();
        
        foreach ($languages as $code => $name) {
            $language_data[] = array(
                'code' => $code,
                'name' => $name,
                'url' => pll_home_url($code),
                'flag' => pll_languages_list(array('fields' => 'flag'))[$code] ?? '',
                'is_default' => pll_default_language() === $code
            );
        }
        
        return $language_data;
    }
    
    /**
     * Get current language
     */
    public function get_current_language() {
        if (!$this->is_polylang_active()) {
            return 'es'; // Default fallback
        }
        
        return pll_current_language() ?: pll_default_language();
    }
    
    /**
     * Get default language
     */
    public function get_default_language() {
        if (!$this->is_polylang_active()) {
            return 'es';
        }
        
        return pll_default_language();
    }
    
    /**
     * Filter posts by language
     */
    public function filter_posts_by_language($query, $language = null) {
        if (!$this->is_polylang_active()) {
            return $query;
        }
        
        if (!$language) {
            $language = $this->get_current_language();
        }
        
        $query['lang'] = $language;
        return $query;
    }
    
    /**
     * Get post language
     */
    public function get_post_language($post_id) {
        if (!$this->is_polylang_active()) {
            return $this->get_default_language();
        }
        
        return pll_get_post_language($post_id) ?: $this->get_default_language();
    }
    
    /**
     * Get post translations
     */
    public function get_post_translations($post_id) {
        if (!$this->is_polylang_active()) {
            return array();
        }
        
        return pll_get_post_translations($post_id) ?: array();
    }
    
    /**
     * Set post language
     */
    public function set_post_language($post_id, $language) {
        if (!$this->is_polylang_active()) {
            return false;
        }
        
        return pll_set_post_language($post_id, $language);
    }
    
    /**
     * Create translation group
     */
    public function create_translation_group($posts_array) {
        if (!$this->is_polylang_active()) {
            return false;
        }
        
        // Try different methods based on Polylang version
        if (function_exists('pll_save_post_translations')) {
            return pll_save_post_translations($posts_array);
        }
        
        if (function_exists('pll_set_post_translations')) {
            foreach ($posts_array as $lang => $post_id) {
                pll_set_post_translations($post_id, $posts_array);
            }
            return true;
        }
        
        return false;
    }
    
    /**
     * Get term language
     */
    public function get_term_language($term_id) {
        if (!$this->is_polylang_active()) {
            return $this->get_default_language();
        }
        
        return pll_get_term_language($term_id) ?: $this->get_default_language();
    }
    
    /**
     * Set term language
     */
    public function set_term_language($term_id, $language) {
        if (!$this->is_polylang_active()) {
            return false;
        }
        
        return pll_set_term_language($term_id, $language);
    }
    
    /**
     * Get language switcher
     */
    public function get_language_switcher($args = array()) {
        if (!$this->is_polylang_active()) {
            return '';
        }
        
        $default_args = array(
            'dropdown' => 0,
            'show_names' => 1,
            'show_flags' => 0,
            'hide_current' => 0,
            'force_home' => 0,
            'echo' => 0
        );
        
        $args = wp_parse_args($args, $default_args);
        
        return pll_the_languages($args);
    }
    
    /**
     * Translate string
     */
    public function translate_string($string, $language = null) {
        if (!$this->is_polylang_active()) {
            return $string;
        }
        
        if (!$language) {
            $language = $this->get_current_language();
        }
        
        // Use Polylang string translation if available
        if (function_exists('pll__')) {
            return pll__($string);
        }
        
        return $string;
    }
    
    /**
     * Get language info
     */
    public function get_language_info($language_code) {
        if (!$this->is_polylang_active()) {
            return array(
                'code' => $language_code,
                'name' => $language_code,
                'native_name' => $language_code,
                'flag' => '',
                'rtl' => false
            );
        }
        
        $language = PLL()->model->get_language($language_code);
        
        if (!$language) {
            return null;
        }
        
        return array(
            'code' => $language->slug,
            'name' => $language->name,
            'native_name' => $language->name,
            'flag' => $language->flag,
            'rtl' => (bool) $language->is_rtl,
            'locale' => $language->locale,
            'url' => pll_home_url($language->slug)
        );
    }
    
    /**
     * Check if language exists
     */
    public function language_exists($language_code) {
        if (!$this->is_polylang_active()) {
            return false;
        }
        
        $languages = pll_languages_list();
        return in_array($language_code, $languages);
    }
    
    /**
     * Get posts in all languages
     */
    public function get_multilingual_posts($post_id) {
        $translations = $this->get_post_translations($post_id);
        $posts = array();
        
        foreach ($translations as $lang => $translated_id) {
            $post = get_post($translated_id);
            if ($post) {
                $posts[$lang] = array(
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'content' => $post->post_content,
                    'status' => $post->post_status,
                    'url' => get_permalink($post->ID),
                    'language' => $lang
                );
            }
        }
        
        return $posts;
    }
    
    /**
     * Duplicate post to other languages
     */
    public function duplicate_post_to_languages($post_id, $target_languages = array()) {
        if (!$this->is_polylang_active()) {
            return array();
        }
        
        $original_post = get_post($post_id);
        if (!$original_post) {
            return array();
        }
        
        $original_language = $this->get_post_language($post_id);
        $created_posts = array($original_language => $post_id);
        
        if (empty($target_languages)) {
            $target_languages = pll_languages_list();
            // Remove original language
            $target_languages = array_diff($target_languages, array($original_language));
        }
        
        foreach ($target_languages as $target_lang) {
            // Check if translation already exists
            $existing_translation = pll_get_post($post_id, $target_lang);
            if ($existing_translation) {
                $created_posts[$target_lang] = $existing_translation;
                continue;
            }
            
            // Create new post
            $new_post_data = array(
                'post_title' => $original_post->post_title . ' (' . strtoupper($target_lang) . ')',
                'post_content' => $original_post->post_content,
                'post_status' => 'draft', // Create as draft for manual translation
                'post_type' => $original_post->post_type,
                'post_author' => $original_post->post_author
            );
            
            $new_post_id = wp_insert_post($new_post_data);
            
            if ($new_post_id && !is_wp_error($new_post_id)) {
                // Set language
                $this->set_post_language($new_post_id, $target_lang);
                $created_posts[$target_lang] = $new_post_id;
            }
        }
        
        // Create translation relationships
        if (count($created_posts) > 1) {
            $this->create_translation_group($created_posts);
        }
        
        return $created_posts;
    }
}
