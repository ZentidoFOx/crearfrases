<?php
/**
 * Content Search API - Yoast SEO Integration
 * 
 * @package ContentSearchAPI
 * @version 2.1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class CSA_Yoast {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Check if Yoast SEO is active
     */
    public function is_yoast_active() {
        return class_exists('WPSEO_Meta');
    }
    
    /**
     * Get complete Yoast SEO data for a post
     */
    public function get_yoast_data($post_id) {
        if (!$this->is_yoast_active()) {
            return null;
        }
        
        $yoast_data = array(
            'focus_keyword' => get_post_meta($post_id, '_yoast_wpseo_focuskw', true),
            'title' => get_post_meta($post_id, '_yoast_wpseo_title', true),
            'description' => get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
            'canonical' => get_post_meta($post_id, '_yoast_wpseo_canonical', true),
            
            // SEO Score
            'seo_score' => get_post_meta($post_id, '_yoast_wpseo_linkdex', true),
            'seo_score_text' => $this->get_score_text(get_post_meta($post_id, '_yoast_wpseo_linkdex', true)),
            
            // Readability Score
            'readability_score' => get_post_meta($post_id, '_yoast_wpseo_content_score', true),
            'readability_score_text' => $this->get_score_text(get_post_meta($post_id, '_yoast_wpseo_content_score', true)),
            
            // Open Graph
            'og_title' => get_post_meta($post_id, '_yoast_wpseo_opengraph-title', true),
            'og_description' => get_post_meta($post_id, '_yoast_wpseo_opengraph-description', true),
            'og_image' => get_post_meta($post_id, '_yoast_wpseo_opengraph-image', true),
            
            // Twitter
            'twitter_title' => get_post_meta($post_id, '_yoast_wpseo_twitter-title', true),
            'twitter_description' => get_post_meta($post_id, '_yoast_wpseo_twitter-description', true),
            'twitter_image' => get_post_meta($post_id, '_yoast_wpseo_twitter-image', true),
            
            // Robots
            'robots_noindex' => get_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', true),
            'robots_nofollow' => get_post_meta($post_id, '_yoast_wpseo_meta-robots-nofollow', true),
            
            // Cornerstone
            'is_cornerstone' => get_post_meta($post_id, '_yoast_wpseo_is_cornerstone', true) === '1',
        );
        
        // Calculate overall quality
        $seo_score = intval($yoast_data['seo_score']);
        $readability_score = intval($yoast_data['readability_score']);
        
        if ($seo_score >= 70 && $readability_score >= 60) {
            $yoast_data['overall_quality'] = 'excellent';
            $yoast_data['overall_quality_text'] = 'Excelente';
        } elseif ($seo_score >= 50 && $readability_score >= 40) {
            $yoast_data['overall_quality'] = 'good';
            $yoast_data['overall_quality_text'] = 'Bueno';
        } elseif ($seo_score >= 30 || $readability_score >= 30) {
            $yoast_data['overall_quality'] = 'needs_improvement';
            $yoast_data['overall_quality_text'] = 'Necesita Mejorar';
        } else {
            $yoast_data['overall_quality'] = 'poor';
            $yoast_data['overall_quality_text'] = 'Pobre';
        }
        
        return $yoast_data;
    }
    
    /**
     * Set Yoast SEO data for a post
     */
    public function set_yoast_data($post_id, $seo_data) {
        if (!$this->is_yoast_active()) {
            return false;
        }
        
        $updated_fields = array();
        
        // Focus keyword
        if (isset($seo_data['focus_keyword'])) {
            update_post_meta($post_id, '_yoast_wpseo_focuskw', sanitize_text_field($seo_data['focus_keyword']));
            $updated_fields[] = 'focus_keyword';
        }
        
        // SEO Title
        if (isset($seo_data['title'])) {
            update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($seo_data['title']));
            $updated_fields[] = 'title';
        }
        
        // Meta Description
        if (isset($seo_data['description'])) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field($seo_data['description']));
            $updated_fields[] = 'description';
        }
        
        // Canonical URL
        if (isset($seo_data['canonical'])) {
            update_post_meta($post_id, '_yoast_wpseo_canonical', esc_url_raw($seo_data['canonical']));
            $updated_fields[] = 'canonical';
        }
        
        // Open Graph data
        if (isset($seo_data['og_title'])) {
            update_post_meta($post_id, '_yoast_wpseo_opengraph-title', sanitize_text_field($seo_data['og_title']));
            $updated_fields[] = 'og_title';
        }
        
        if (isset($seo_data['og_description'])) {
            update_post_meta($post_id, '_yoast_wpseo_opengraph-description', sanitize_textarea_field($seo_data['og_description']));
            $updated_fields[] = 'og_description';
        }
        
        if (isset($seo_data['og_image'])) {
            update_post_meta($post_id, '_yoast_wpseo_opengraph-image', esc_url_raw($seo_data['og_image']));
            $updated_fields[] = 'og_image';
        }
        
        // Twitter data
        if (isset($seo_data['twitter_title'])) {
            update_post_meta($post_id, '_yoast_wpseo_twitter-title', sanitize_text_field($seo_data['twitter_title']));
            $updated_fields[] = 'twitter_title';
        }
        
        if (isset($seo_data['twitter_description'])) {
            update_post_meta($post_id, '_yoast_wpseo_twitter-description', sanitize_textarea_field($seo_data['twitter_description']));
            $updated_fields[] = 'twitter_description';
        }
        
        if (isset($seo_data['twitter_image'])) {
            update_post_meta($post_id, '_yoast_wpseo_twitter-image', esc_url_raw($seo_data['twitter_image']));
            $updated_fields[] = 'twitter_image';
        }
        
        // Robots meta
        if (isset($seo_data['robots_noindex'])) {
            $value = $seo_data['robots_noindex'] ? '1' : '0';
            update_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', $value);
            $updated_fields[] = 'robots_noindex';
        }
        
        if (isset($seo_data['robots_nofollow'])) {
            $value = $seo_data['robots_nofollow'] ? '1' : '0';
            update_post_meta($post_id, '_yoast_wpseo_meta-robots-nofollow', $value);
            $updated_fields[] = 'robots_nofollow';
        }
        
        // Cornerstone content
        if (isset($seo_data['is_cornerstone'])) {
            $value = $seo_data['is_cornerstone'] ? '1' : '0';
            update_post_meta($post_id, '_yoast_wpseo_is_cornerstone', $value);
            $updated_fields[] = 'is_cornerstone';
        }
        
        return $updated_fields;
    }
    
    /**
     * Get score text from numeric score
     */
    public function get_score_text($score) {
        $score = intval($score);
        
        if ($score >= 70) {
            return array(
                'status' => 'good',
                'color' => 'green',
                'text' => 'Bueno',
                'emoji' => '✅'
            );
        } elseif ($score >= 50) {
            return array(
                'status' => 'ok',
                'color' => 'orange',
                'text' => 'OK',
                'emoji' => '⚠️'
            );
        } else {
            return array(
                'status' => 'bad',
                'color' => 'red',
                'text' => 'Malo',
                'emoji' => '❌'
            );
        }
    }
    
    /**
     * Analyze content for SEO issues
     */
    public function analyze_content($content, $focus_keyword = '') {
        $issues = array();
        $recommendations = array();
        
        // Content length analysis
        $word_count = str_word_count(strip_tags($content));
        if ($word_count < 300) {
            $issues[] = array(
                'type' => 'content_length',
                'severity' => 'high',
                'message' => 'El contenido es muy corto. Se recomiendan al menos 300 palabras.',
                'current_value' => $word_count,
                'recommended_value' => 300
            );
        }
        
        // Focus keyword analysis
        if (!empty($focus_keyword)) {
            $keyword_density = $this->calculate_keyword_density($content, $focus_keyword);
            
            if ($keyword_density < 0.5) {
                $issues[] = array(
                    'type' => 'keyword_density_low',
                    'severity' => 'medium',
                    'message' => 'La densidad de la palabra clave es muy baja.',
                    'current_value' => $keyword_density,
                    'recommended_value' => '0.5-2.5%'
                );
            } elseif ($keyword_density > 2.5) {
                $issues[] = array(
                    'type' => 'keyword_density_high',
                    'severity' => 'medium',
                    'message' => 'La densidad de la palabra clave es muy alta. Podría considerarse spam.',
                    'current_value' => $keyword_density,
                    'recommended_value' => '0.5-2.5%'
                );
            }
        }
        
        // Heading structure analysis
        $headings = $this->extract_headings($content);
        if (empty($headings['h1'])) {
            $issues[] = array(
                'type' => 'missing_h1',
                'severity' => 'high',
                'message' => 'Falta el encabezado H1 principal.'
            );
        }
        
        if (count($headings['h2']) < 2) {
            $recommendations[] = array(
                'type' => 'add_h2_headings',
                'message' => 'Considera agregar más encabezados H2 para mejorar la estructura del contenido.'
            );
        }
        
        return array(
            'issues' => $issues,
            'recommendations' => $recommendations,
            'stats' => array(
                'word_count' => $word_count,
                'keyword_density' => !empty($focus_keyword) ? $keyword_density : 0,
                'headings_count' => array_sum(array_map('count', $headings))
            )
        );
    }
    
    /**
     * Calculate keyword density
     */
    private function calculate_keyword_density($content, $keyword) {
        $text = strip_tags($content);
        $text = strtolower($text);
        $keyword = strtolower($keyword);
        
        $word_count = str_word_count($text);
        $keyword_count = substr_count($text, $keyword);
        
        if ($word_count === 0) {
            return 0;
        }
        
        return round(($keyword_count / $word_count) * 100, 2);
    }
    
    /**
     * Extract headings from content
     */
    private function extract_headings($content) {
        $headings = array(
            'h1' => array(),
            'h2' => array(),
            'h3' => array(),
            'h4' => array(),
            'h5' => array(),
            'h6' => array()
        );
        
        for ($i = 1; $i <= 6; $i++) {
            preg_match_all('/<h' . $i . '[^>]*>(.*?)<\/h' . $i . '>/i', $content, $matches);
            $headings['h' . $i] = array_map('strip_tags', $matches[1]);
        }
        
        return $headings;
    }
}
